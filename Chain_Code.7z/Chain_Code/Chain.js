﻿$(function () {
    debugger;
    let EMNNO = sessionStorage.getItem("emnno");
    if (EMNNO != '') {
        BindChain();
    }
    let EMCNO = sessionStorage.getItem("emcno");
    let EMCNM = sessionStorage.getItem("emcnm");
    if (EMCNO != null && EMCNM != null) {
        $("#eventHeading").text(EMCNO + ' - ' + EMCNM);
    }
});



function BindChain() {

 
    try {
        //var data = {
        //    CHNNO: 0
        //};

        $.ajax({
            url: '/Chain/GetChain',
            
          //  data: data,
            async: false,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {

                OnChainList(response);
            },
            failure: function (response) {
                alert(response.d);
            },
            error: function (response) {
                alert(response.d);
            }
        });
    } catch (e) {
        console.log(e);

    }
}


// On success of Bind Chain List
function OnChainList(response) {
    debugger;

    $("#ChainList").DataTable(
        {
            lengthMenu: [[10, 30, -1], [10, 30, "All"]],
            "pageLength": 10,
            data: response,
            "bDestroy": true,
            columns: [
                { 'data': 'chcacro' },
                { 'data': 'action' },
                { 'data': 'chcorg' },
                { 'data': 'chccity' },
                { 'data': 'chcst' },
                { 'data': 'chczip' },
                { 'data': 'chcctry' },
                
            ]
            //bServerSide: true,
            //sAjaxSource: 'EmployeeDataHandler.ashx',

            //"oLanguage": {
            //    "sEmptyTable": "No Record found!"

            //}
        });
    $.fn.dataTable.ext.errMode = 'none';
}

function EditChainDtl(ID) {
    var data = {
        CHNNO: ID,
        CUNNO: ("#CUNNO").val(),
        CHCACRO: ("#CHCACRO").val(),
        CHCORG: ("#CHCORG").val(),
        CHCAD1: ("#CHCAD1").val(),
        CHCAD2: ("#CHCAD2").val(),
        CHCCITY: ("#CHCCITY").val(),
        CHCST: ("#CHCST").val(),
        CHCZIP: ("#CHCZIP").val(),
        CHCREGN: ("#CHCREGN").val(),
        CHCCTRY: ("#CHCCTRY").val(),
        CHCTEL: ("#CHCTEL").val(),
        CHCFAX: ("#CHCFAX").val(),
        CHCEMAIL: ("#CHCEMAIL").val(),
        CHCCONTACT_FIRST: ("#CHCCONTACT_FIRST").val(),
        CHCCONTACT_LAST: ("#CHCCONTACT_LAST").val(),
        CHCCONTACT_TITLE: ("#CHCCONTACT_TITLE").val(),
        CHCCONTACT_TEL: ("#CHCCONTACT_TEL").val(),
        CHCCONTACT_FAX: ("#CHCCONTACT_TEL").val(),
        CHCCONTACT_EMAIL: ("#CHCCONTACT_TEL").val(),
        CHCCOMMENTS: ("#CHCCONTACT_TEL").val(),
    }

    $.ajax({
        url: '/Chain/AddUpdateChainList',
        type:"post",
         data: data,
        async: false,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            alert("Updated");
        },
        failure: function (response) {
            alert(response.d);
        },
        error: function (response) {
            alert(response.d);
        }
    });


}