﻿

using EventManagerAPI.DataAccess.HelperRepository.IHelperRepository;
using EventManagerAPI.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Globalization;
using System.Net.NetworkInformation;
using static EventManagerAPI.Entities.sub_categoryHotel;

namespace EventManagerAPI.DataAccess
{

    public class ChainDA
    {
        DataSet ds;
        private readonly IEventManagerConfigManager _configuration;

        public ChainDA(IEventManagerConfigManager configuration)
        {
            _configuration = configuration;
        }


        public DataSet GetChainList(getchainList obj)
        {
            try
            {
                SqlParameter[] param = new SqlParameter[1];
                param[0] = new SqlParameter("@CHNNO", obj.CHNNO);
                ds = SqlHelper.ExecuteDataSet(_configuration.NorthwindConnection, "usp_icm_get_ChainList", CommandType.StoredProcedure, param);
            }
            catch (Exception ex)
            {
                ds = null;
                // ExceptionLogging.Log(ex);
            }
            return ds;
        }
        public DataSet AddUpdateChainList(getchainList obj)
        {
            // usp_icm_get_EditChainDtl
            
            try
            {
                SqlParameter[] param = new SqlParameter[20];    
                param[0] = new SqlParameter("@CHNNO", obj.CHNNO);  
                param[1] = new SqlParameter("@CHCACRO", obj.CHCACRO);         
                param[2] = new SqlParameter("@CHCORG", obj.CHCORG);             
                param[3] = new SqlParameter("@CHCAD1", obj.CHCAD1);              
                param[4] = new SqlParameter("@CHCAD2", obj.CHCAD2);             
                param[5] = new SqlParameter("@CHCCITY", obj.CHCCITY);          
                param[6] = new SqlParameter("@CHCST", obj.CHCST);                  
                param[7] = new SqlParameter("@CHCZIP", obj.CHCZIP);               
                param[8] = new SqlParameter("@CHCREGN", obj.CHCREGN);         
                param[9] = new SqlParameter("@CHCCTRY", obj.CHCCTRY);          
                param[10] = new SqlParameter("@CHCTEL", obj.CHCTEL);               
                param[11] = new SqlParameter("@CHCFAX", obj.CHCFAX);             
                param[12] = new SqlParameter("@CHCEMAIL", obj.CHCEMAIL);     
                param[13] = new SqlParameter("@CHCCONTACT_FIRST", obj.CHCCONTACT_FIRST);      
                param[14] = new SqlParameter("@CHCCONTACT_LAST", obj.CHCCONTACT_LAST);          
                param[15] = new SqlParameter("@CHCCONTACT_TITLE", obj.CHCCONTACT_TITLE);       
                param[16] = new SqlParameter("@CHCCONTACT_TEL", obj.CHCCONTACT_TEL);               
                param[17] = new SqlParameter("@CHCCONTACT_FAX", obj.CHCCONTACT_FAX);              
                param[18] = new SqlParameter("@CHCCONTACT_EMAIL", obj.CHCCONTACT_EMAIL);     
                param[19] = new SqlParameter("@CHCCOMMENTS", obj.CHCCOMMENTS);                      
                ds = SqlHelper.ExecuteDataSet(_configuration.NorthwindConnection, "usp_icm_get_AddupadteChainDtl", CommandType.StoredProcedure, param);
            }
            catch (Exception ex)
            {
                ds = null;
                // ExceptionLogging.Log(ex);
            }
            return ds;
        }
    }

}
