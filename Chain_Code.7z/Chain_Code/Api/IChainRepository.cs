﻿
using EventManagerAPI.Entities;
using EventManagerAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EventManagerAPI.Repository.IRepository
{
    public interface IChainRepository
    {
        List<getchainList> GetChainList(getchainList obj);
        List<getchainList> AddUpdateChainList(getchainList obj);
    }
}

