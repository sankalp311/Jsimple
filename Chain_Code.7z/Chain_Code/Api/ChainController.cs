﻿using AutoMapper;
using EventManagerAPI.Entities;
using EventManagerAPI.Models;
using EventManagerAPI.Repository.IRepository;
using icmAPI.Entities;
using icmAPI.Models;
using icmAPI.Repository.IRepository;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace EventManagerAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [EnableCors("AllowedHosts")]
    public class ChainController : Controller
    {
        private IChainRepository _eRepo;
        private readonly IMapper _mapper;

        public ChainController(IChainRepository eRepo, IMapper mapper)
        {
            _eRepo = eRepo;
            _mapper = mapper;

        }

        [HttpPost]
        public IActionResult GetChainList([FromBody] getchainList obj)
        {
            var objChain = _eRepo.GetChainList(obj);
            return Ok(objChain);
        }
        
        [HttpPost]
        public IActionResult AddUpdateChainList([FromBody] getchainList obj)
        {
            var objChain = _eRepo.AddUpdateChainList(obj);
            return Ok(objChain);
        }

    }
}
