﻿


using System;

namespace EventManagerAPI.Entities
{
    public class getchainList
    {
        public int CHNNO { get; set; }
        public int CUNNO { get; set; }
        public string CHCACRO { get; set; }
        public string CHCORG { get; set; }
        public string CHCAD1 { get; set; }
        public string CHCAD2 { get; set; }
        public string CHCCITY { get; set; }
        public string CHCST { get; set; }
        public string CHCZIP { get; set; }
        public string CHCREGN { get; set; }
        public string CHCCTRY { get; set; }
        public string CHCTEL { get; set; }
        public string CHCFAX { get; set; }
        public string CHCEMAIL { get; set; }
        public string CHCCONTACT_FIRST { get; set; }
        public string CHCCONTACT_LAST { get; set; }
        public string CHCCONTACT_TITLE { get; set; }
        public string CHCCONTACT_TEL { get; set; }
        public string CHCCONTACT_FAX { get; set; }
        public string CHCCONTACT_EMAIL { get; set; }
        public string CHCCOMMENTS { get; set; }
        public string ACTION { get; set; }
    }

}
