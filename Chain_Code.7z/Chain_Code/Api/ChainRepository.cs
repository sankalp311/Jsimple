﻿











using EventManagerAPI.DataAccess;
using EventManagerAPI.DataAccess.HelperRepository.IHelperRepository;
using EventManagerAPI.Entities;
using EventManagerAPI.Repository.IRepository;
using icmAPI.DataAccess;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Net.NetworkInformation;
using static EventManagerAPI.Entities.sub_categoryHotel;

namespace EventManagerAPI.Repository
{
    public class ChainRepository : IChainRepository
    {
        private readonly IEventManagerConfigManager _configuration;

        public ChainRepository(IEventManagerConfigManager configuration)
        {
            _configuration = configuration;
        }

        public List<getchainList> GetChainList(getchainList obj)
        {
            List<getchainList> item = new List<getchainList>();
            ChainDA _RegistrationAdminDA = new ChainDA(_configuration);
            DataSet ds = new DataSet();
            ds = _RegistrationAdminDA.GetChainList(obj);
            if (ds?.Tables[0]?.Rows.Count > 0)
            {
                item = ds.Tables[0].AsEnumerable().Select(x => new getchainList()
                {
                    //CHNNO = Convert.ToInt32(x.Field<int>("CHNNO")),
                    //CUNNO = Convert.ToInt32(x.Field<int>("CUNNO")),
                    CHCACRO = Convert.ToString(x.Field<string>("CHCACRO")),
                    CHCORG = Convert.ToString(x.Field<string>("CHCORG")),
                    //CHCAD1 = Convert.ToString(x.Field<string>("CHCAD1")),
                    //CHCAD2 = Convert.ToString(x.Field<string>("CHCAD2")),
                    CHCCITY = Convert.ToString(x.Field<string>("CHCCITY")),
                    CHCST = Convert.ToString(x.Field<string>("CHCST")),
                    CHCZIP = Convert.ToString(x.Field<string>("CHCZIP")),
                    //CHCREGN = Convert.ToString(x.Field<string>("CHCREGN")),
                    CHCCTRY = Convert.ToString(x.Field<string>("CHCCTRY")),
                    //CHCTEL = Convert.ToString(x.Field<string>("CHCTEL")),
                    //CHCFAX = Convert.ToString(x.Field<string>("CHCFAX")),
                    //CHCEMAIL = Convert.ToString(x.Field<string>("CHCEMAIL")),
                    //CHCCONTACT_FIRST = Convert.ToString(x.Field<string>("CHCCONTACT_FIRST")),
                    //CHCCONTACT_LAST = Convert.ToString(x.Field<string>("CHCCONTACT_LAST")),
                    //CHCCONTACT_TITLE = Convert.ToString(x.Field<string>("CHCCONTACT_TITLE")),
                    //CHCCONTACT_TEL = Convert.ToString(x.Field<string>("CHCCONTACT_TEL")),
                    //CHCCONTACT_FAX = Convert.ToString(x.Field<string>("CHCCONTACT_FAX")),
                    //CHCCONTACT_EMAIL = Convert.ToString(x.Field<string>("CHCCONTACT_EMAIL")),
                //    CHCCOMMENTS = Convert.ToString(x.Field<string>("CHCCOMMENTS")),
                    ACTION = x.Field<string>("ACTION")
                }).ToList();
            }
            return item;
        }


    }
}



