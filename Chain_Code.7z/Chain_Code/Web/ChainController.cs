﻿using EventManagerWeb.Areas.Admin.Models;
using EventManagerWeb.Repository.IRepository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace EventManagerWeb.Areas.Admin.Controllers
{
    public class ChainController : Controller
    {
        private readonly IChainRepository _cRepo;

        public ChainController(IChainRepository cRepo)
        {
            _cRepo = cRepo;
        }
        public IActionResult Index()
        {
            return View();
        }
        public async Task<IActionResult> GetChain()
        {
            getchainList obj = new getchainList();
            obj.CHNNO = 0;
            var chainList = await _cRepo.GetChainDtl(obj);
            return this.Ok(chainList);
        }

        

            [HttpPost]
        public async Task<IActionResult> AddUpdateChainList(getchainList objPraram)
        {
            var Result = await _cRepo.AddUpdateChainList(objPraram);
            return this.Ok(Result);
        }
    }
}
