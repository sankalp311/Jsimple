﻿using EventManagerWeb.Areas.Admin.Models;
using EventManagerWeb.Repository.IRepository;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace EventManagerWeb.Repository
{
    public class ChainRepository : IChainRepository
    {
        private readonly IHttpClientFactory _ClientFactory;
        private readonly AppSettings _AppSettings;
        public ChainRepository(IHttpClientFactory ClientFactory, IOptions<AppSettings> appSettings)
        {
            _ClientFactory = ClientFactory;
            _AppSettings = appSettings.Value;
        }

        public async Task<List<getchainList>> GetChainDtl(getchainList obj)
        {
            List<getchainList> obj_cls_Chain = new List<getchainList>();
            var request = new HttpRequestMessage(HttpMethod.Post, _AppSettings.ApiRootUrl + "Chain/GetChainList");
            if (obj != null)
            {
                request.Content = new StringContent(JsonConvert.SerializeObject(obj), Encoding.UTF8, "application/json");
            }
            else
            {
                return null;
            }
            var client = _ClientFactory.CreateClient();
            HttpResponseMessage respose = await client.SendAsync(request);
            if (respose.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var jsonString = await respose.Content.ReadAsStringAsync();
                obj_cls_Chain = JsonConvert.DeserializeObject<List<getchainList>>(jsonString);
                return obj_cls_Chain;
            }
            else
            {
                return null;
            }
        }
        public async Task<List<getchainList>> AddUpdateChainList(getchainList obj)
        {
            List<getchainList> obj_cls_Chain = new List<getchainList>();
            var request = new HttpRequestMessage(HttpMethod.Post, _AppSettings.ApiRootUrl + "Chain/GetChainList");
            if (obj != null)
            {
                request.Content = new StringContent(JsonConvert.SerializeObject(obj), Encoding.UTF8, "application/json");
            }
            else
            {
                return null;
            }
            var client = _ClientFactory.CreateClient();
            HttpResponseMessage respose = await client.SendAsync(request);
            if (respose.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var jsonString = await respose.Content.ReadAsStringAsync();
                obj_cls_Chain = JsonConvert.DeserializeObject<List<getchainList>>(jsonString);
                return obj_cls_Chain;
            }
            else
            {
                return null;
            }
        }


    }
}
