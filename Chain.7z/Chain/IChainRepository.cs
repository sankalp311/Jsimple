﻿
using EventManagerWeb.Areas.Admin.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EventManagerWeb.Repository.IRepository
{
    public interface IChainRepository
    {
        Task<List<getchainList>> GetChainDtl(getchainList obj);
        Task<List<getchainList>> AddUpdateChainList(getchainList obj);
    }
}
